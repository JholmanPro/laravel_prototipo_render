<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;

Route::get('/registro', function() {
    return view('auth.register');
});

Route::post('/registro', [AuthController::class, 'register']);